A = float(input())
N = int(input())
P = 1
for i in range(1, N+1):
    P =P*A
    print(P)
print(P)
