x = int(input())
y = int(input())
z = 1
while x < y:
    x = x * 1.1
    z = z+1
print(z)
