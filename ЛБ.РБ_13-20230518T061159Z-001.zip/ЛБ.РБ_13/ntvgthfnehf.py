m = float(input('m='))
t1 = float(input('t1='))        
t2 = float(input('t2='))
c = float(input('c='))
Q=c*m*(t2-t1)
print("Q:",round(Q,5))

          
