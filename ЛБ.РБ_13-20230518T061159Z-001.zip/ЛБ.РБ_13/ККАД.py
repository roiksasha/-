v = int(input())
t = int(input())
x = v * t % 109
print(x)
